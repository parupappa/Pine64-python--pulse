https://docs.google.com/document/d/1IvCVnEEKkVlhoXtP7Bev6jJQLPHSNEKsXitk3iIuIDc/edit?usp=sharing

上記リンクからREADME.txt の　GoogleDocument を閲覧・編集できます。